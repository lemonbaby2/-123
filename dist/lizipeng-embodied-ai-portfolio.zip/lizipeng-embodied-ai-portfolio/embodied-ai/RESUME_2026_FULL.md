# 简历全文归档（2026 版）

> 原文件：[`resume/2026_李梓鹏_具身智能机器人简历.pdf`](resume/2026_李梓鹏_具身智能机器人简历.pdf)（3 页，349 KB，sha256 `1d42aab0eae63e71…`）
>
> 本页是 PDF 的结构化转录，**逐字照抄，未改写、未润色、未补数字**。原稿的日期倒挂、错字等问题以 `〔原文如此〕` 标注，供后续投递前修正。
>
> 转录规则：只做版式重组（标题层级、表格化时间线），不改动任何指标、机构名和资历表述。
>
> **联系方式已打码**（`<PHONE>` / `<EMAIL>`），与 [`docs/RESUME.md`](../docs/RESUME.md) 的脱敏口径一致。需要完整版请通过 GitHub Issue 索取。

---

## 一、基本信息

| 项 | 内容 |
|---|---|
| 姓名 | 李梓鹏 |
| 求职意向 | 具身智能 SLAM & VLA & VLM 算法 + 边缘部署 |
| 年龄 | 23 |
| 学历 | 本科 |
| 电话 | `<PHONE>` |
| 籍贯 | 广州 |
| 求职地点 | 广州 / 深圳 |
| E-mail | `<EMAIL>` |

## 二、教育背景

**广东工业大学 · 新能源电子器件**　2020.09 — 2024.07；2025.08 — 至今

- GPA 3.6/5.0（年级排名 10/86）
- 英语：雅思 6.5 / 六级 461
- 竞赛：2025 届华为杯全国数学建模大赛 国家三等奖；2023 年广东省大学生数学建模竞赛 省级二等奖；第 17 届挑战杯广东省赛 一等奖

**专利（3 项发明专利，已受理）**

1. 《基于多模态感知与高斯原语的地图构建方法、装置及介质》
2. 《基于多传感器融合的手持式 SLAM 测绘扫描仪及高精度三维重建方法》
3. 《一种基于深度学习模型的自动化边缘部署》

**论文（中科院一区 · 在投）**

《Dy3DGS-SLAM: A Dynamic Monocular RGB 3D Gaussian Splatting Visual SLAM System for Robust Scene Reconstruction in Dynamic Environments》

## 三、工作经历

### 3.1 广州现代信息工程职业技术学院 · 人工智能讲师　2025.09 — 至今

- **项目背景**：担任专任讲师，主导四足机器人在复杂动态场景下的自主导航与运动决策项目。
- **主要职责**：负责对 SLAM 前端与点云处理模块进行 C++ 轻量化改造，将模型与传统算法模块统一封装于 ROS2 + Gazebo 仿真及实机平台（Orin AGX + IMU + LiDAR + RGB-D），使用 CUDA 优化点云滤波与 ICP 配准，系统定位频率加速至 10 Hz。
- **成果**：金砖国家智能体全国赛三等奖；提出融合 IMU 预积分改进的 LOAM（LOAM+IMU）前端、视觉回环（SuperPoint+SuperGlue）与任务感知决策层（GNN+Transformer）的完整方案。

### 3.2 广州图灵科技有限公司（校企合作）· 开发项目负责人　2026.07 — 2026.08

- **项目背景**：为 Ginger 服务机器人注入 VLM/VLA 大模型能力，基于 CCU ROS 底层接口，实现大模型驱动的本地多模态交互、自主导航与具身控制系统开发。
- **主要职责**：
  1. 构建 VLM/VLA - ROS 具身控制链路：基于 Ginger 机器人 CCU 底层，开发 VLM（视觉语言模型）与 VLA 到 ROS 的接口。
  2. 本地控制系统开发：诊断并定位物理网口链路中断（USB 网卡 Disconnected / 0 bps）为当前阻塞点，基于 rosbridge WebSocket 接口和 HTTP，实现大模型输出指令与 ROS 导航系统（LoadMap 接口）的深度融合。
  3. 规划 rosbridge（9090 端口）WebSocket 接口接入与地图动态加载（LoadMap 接口）。
- **主要成果**：
  1. 设计三阶段协同压缩流水线，Jetson Orin NX 推理 175 ms → 48 ms（加速 3.65×），mAP 损失 < 1.2%；并通过 TensorRT 算子融合完成自动化边缘部署。
  2. 实现 CCU 本地自主控制链路搭建。完成 SSH 远程调试、ROS 核心服务验证、导航与定位状态读取。
  3. 成功在端侧（Orin NX）实现 VLM/VLA 的高效推理部署，通过算子融合与 Pipeline 优化，延迟降至 48 ms，并实现自动化边缘部署。

### 3.3 广州吉得奥科技有限公司（校企合作）· 算法负责人 / 项目负责人　2025.11 — 2026.05

- **项目背景**：主导 GeoScan Pro 系列手持式三维测绘扫描仪的全栈算法与系统研发。
- **主要职责**：
  1. 负责 GeoScan Pro 整机技术路线规划、算法架构设计、任务拆解、团队协作及阶段验收。
  2. 统筹激光雷达、IMU、RTK、相机、STM32、Jetson、ROS2、SLAM、AI 感知及 Android AIoT App。
  3. 构建基于 LIO-SAM、GTSAM 和 iSAM2 的多传感器因子图优化框架，将单目视觉 SLAM、动态目标分割和 3D Gaussian Splatting 统一。
- **主要成果**：
  1. 3 项发明专利，共约 30 项权利要求；2 篇 IEEE 期刊论文；2 项软件著作权。
  2. 形成 GeoScan Pro 手持式 SLAM 智能测绘扫描仪产品目标售价约 5.8 万元，较 20 万元以上的进口同类产品降低约 71%。
  3. STM32—Jetson USB-CDC 通信链路带宽余量达到约 94%，能够稳定传输设备状态、时间戳及控制信息。
  4. 完成 LiDAR、IMU、视觉和 RTK 多源融合因子图系统搭建，双天线 RTK 航向精度小于 0.2°。

### 3.4 斑马技术服务（广州）有限公司 · 机器视觉工程师　2025.01 — 2025.09

- **项目背景**：针对 ZT421T / 桌面工业打印机，解决标签偏位（初始漏检率 15%）及电机故障等生产质量问题，开发并落地工业缺陷检测系统。
- **主要职责**：
  1. 基于 20 MP 索尼 IMX677 工业相机与 NVIDIA Jetson AGX Orin，搭建 YOLOv11 缺陷检测系统。
  2. 开发 LSTM + R-CNN 融合模型用于电机故障预测，利用 TensorRT C++ API 完成 INT8 量化加速并部署。
- **主要成果**：
  1. 改进 YOLOv11，新增 P2 特征层，小目标（0.5 mm 喷头损伤）AP 提升 12%，漏检率由 15% 降低至 9%（↓40%），编码丢失率控制至 0.3%。
  2. 基于 Jetson Orin TensorRT INT8 量化，推理延迟从 42 ms 优化至 18 ms（↓57%）。

## 四、项目经历

### 4.1 世界模型：机器人场景预测与 Real2Sim 验证 · 算法负责人　2026.06 — 2026.09

- **项目背景**：在现有 ROS2 + 3DGS 场景可视化基础上，规划从静态场景重建扩展至动作条件下的动态预测，用于机器人行为预演、风险分析与仿真数据生成。
- **主要职责**：多模态高频数据采集与对齐 —— 搭建相机序列、机器人关节状态及控制动作（Action）的高频时空同步数据集；在 Isaac Sim 中完成物理参数校准与多维度域随机化（Domain Randomization）设置。
- **主要成果**：
  1. 高精度预测与重构：成功实现 20+ 帧连续动作条件下的场景与状态预测，多步预测误差（MSE）对比基线降低 32%，Real2Sim 渲染与真实观察重构 PSNR 达到 28.5 dB。
  2. 将世界模型预测接入机器人行为预演与碰撞风险分析，使机械臂在未知环境下的规避碰撞成功率提升 25%。

### 4.2 VLA：语言指令驱动的机器人操作策略研究 · 算法负责人　2025.03 — 2025.06

- **项目背景**：面向机器人执行"识别指定零件 — 抓取 — 放置"等自然语言任务，设计视觉、语言与动作联合建模方案，衔接已有 ROS2、Jetson 与机器人控制经验。
- **主要职责**：VLA 基线构建与数据规范 —— 基于 OpenVLA 与 LeRobot 兼容策略搭建具身操作策略，制定高质量遥操作示教数据采集规范，构建包含多视角图像、文本指令、关节状态及末端位姿的时间同步数据集（1000+ 轨迹组）。
- **主要成果**：高泛化与实时推理 —— 策略在未见零件（Zero-Shot 泛化）抓取与放置任务中取得 92.5% 的操作成功率，端到端推理延迟控制在 60 ms 以内；策略成功部署于 Jetson Orin 边缘计算平台并在物理机器上运行。

### 4.3 VLM：工业装配视觉问答与 SOP 工序理解 · 算法负责人　2026.01 — 2025.03〔原文如此，日期倒挂〕

- **项目背景**：面向仪表盘装配中的零件辨识、操作解释与漏步骤提示，设计检测定位与视觉语言模型协同方案，让工程人员能够查询当前工序、依据和异常原因。
- **主要职责**：VLM 工业微调与数据构建 —— 基于 Qwen2.5-VL 构建视觉问答基线，联合 YOLO 细粒度检测与 ByteTrack 跟踪轨迹，构建"画面—目标 ROI—步骤—证据帧"结构化数据集，创新性将 VLM 语义解释与 SOP 有限状态机（FSM）解耦，引入时序判定逻辑。
- **主要成果**：高召回与低幻觉 —— 实现装配过程中的漏装/错装 98.2% 召回率，VLM 视觉问答幻觉率控制在 3.5% 以下，精准识别工序异常。

### 4.4 ROS2 + 3D Gaussian Splatting 场景可视化（Lego）· SLAM 导航算法　2024.04 — 2024.07

- **项目背景**：将 Lego 静态 3DGS 场景接入 ROS2 / RViz2，在 map 坐标系中完成高斯原语可视化，为后续 Real2Sim 与数字孪生验证建立数据通路。
- **主要职责**：
  1. 完成 gaussian_ros_viz 工作空间编译、资源加载、RViz 配置与固定坐标系对齐；围绕 topic、frame_id / TF 和消息时序排查显示问题。
  2. 验证 Ubuntu 22.04 + ROS2 下的场景加载、视角交互与录屏流程，沉淀可复现启动配置。
- **项目成果**：完成 Lego 3DGS 场景 RViz2 演示并输出 12 秒 H.264 视频；形成高斯资源到 ROS2 可视化最小闭环，为接入 Isaac Sim / Real2Sim 评测预留接口。

### 4.5 机器人 SLAM / 点云模块 C++ 轻量化部署（四足机器人）　2023.06 — 2023.10

- **项目背景**：面向四足机器人原始 SLAM 与点云处理模块计算开销大，边缘端定位频率不足、回环检测延迟高。
- **主要职责**：
  1. 对点云特征提取网络进行蒸馏压缩，对配准与回环模块做 C++ 算子级优化，用 CUDA 加速体素滤波、ICP 配准等关键环节；统一封装于 ROS2 框架，开发高性能 C++ ROS2 节点。
  2. 在 Orin AGX 平台完成多线程调度、消息同步与实时推理控制，通过 Vicon 运动捕捉数据与实机轨迹对比进行定量精度评测。
- **项目成果**：回环检测平均延迟降低约 63%；复杂动态场景下定位误差控制在 ±3 cm 以内（Vicon 实测）；系统在室内外混合复杂环境连续稳定运行超过 100 小时。

### 4.6 STM32-FreeRTOS 主动均衡 BMS 开发　2024.01 — 2024.05

- **项目背景**：面向主动均衡 BMS 的 SOC/SOH 估计与故障预测任务，原始时序模型体积较大。
- **主要职责**：
  1. 采用知识蒸馏将 Bi-LSTM 教师模型时序表达能力迁移至更小学生模型，结合剪枝、特征降维与量化感知训练降低模型复杂度；采用 C 语言实现 MCU 端推理逻辑。
  2. 将压缩模型部署至 STM32 + FreeRTOS 平台，完成推理逻辑封装、实时任务调度、内存管理与接口通信；搭建上位机 C++ 训练-导出-验证工具链。
- **项目成果**：SOC 估算误差控制在 2% 以内；系统在低功耗 MCU 上稳定运行，结合 AEKF 与 ISO 26262 功能安全要求，支持 BMS 主动均衡控制与故障预警。

## 五、专业技能

| 维度 | 内容 |
|---|---|
| 编程语言 | C/C++（熟练，主要开发语言）、Python（熟练）、MATLAB |
| 视觉与算法 | OpenCV、YOLOv8/v11、目标检测与分割、SLAM（FAST-LIVO2、ORB-SLAM3、点云配准、ICP、回环检测）、3D Gaussian Splatting |
| 深度学习与具身仿真 | PyTorch、TensorFlow、Transformer、3DGS；Isaac Sim / Isaac Lab（USD、传感器、域随机化、强化/模仿学习，在学） |
| 模型部署与优化 | PyTorch、Transformer、TensorRT（INT8/FP16 量化、C++ API）、ONNX Runtime、模型蒸馏与剪枝 |
| 机器人与实时系统 | STM32 / FreeRTOS、Jetson、ROS2 / ros2_control、EtherCAT / DC、CANopen、RT-PREEMPT、Zero-Copy / Lock-free（在学） |
| 英语 | 雅思 6.5 / 六级 461 |

---

## 六、简历条目 → 仓库目录映射

诚实标注每个条目在本仓库能查到什么、查不到什么。**"仓库实测"只指本仓库脚本能跑出来的结果**；其余一律视为简历报告值。

| # | 简历条目 | 仓库对应位置 | 可验证部分 | 未公开部分 |
|---|---|---|---|---|
| 3.1 / 4.5 | 四足 SLAM + 点云 C++ 轻量化 | [`projects/01_quadruped_slam`](../projects/01_quadruped_slam/) | 体素降采样、2D ICP、IMU 积分、回环门控 | CUDA 实现、ROS bag、Vicon 真值、整机控制器 |
| 3.2 | Ginger 服务机器人 VLM/VLA | [`projects/02_ginger_robot`](../projects/02_ginger_robot/) | rosbridge 消息构造、恢复状态机、路径校验 | 厂商 CCU 协议、实机导航链路 |
| 3.3 | GeoScan Pro 多传感器扫描仪 | [`projects/03_geoscan_pro`](../projects/03_geoscan_pro/) · [`08_3dgs_scanner_soft_hardware`](../projects/08_3dgs_scanner_soft_hardware/) | USB-CDC 帧协议、CRC、因子图最小实现、PCB 文档 | Altium 源文件、Gerber、固件、RTK 实测 |
| 3.4 | 斑马工业视觉质检 | [`projects/04_industrial_vision`](../projects/04_industrial_vision/) | TP/FP/FN 指标、P2 层检查、INT8 量化误差界 | 产线图像、YOLO 权重、TensorRT engine |
| 4.1 | 世界模型 / Real2Sim | [`embodied-ai/experiments/microduck_sprint`](experiments/microduck_sprint/) · [`docs/RESEARCH.md`](../docs/RESEARCH.md) | Isaac Lab 训练流程、策略训练实验记录 | 原世界模型训练代码、PSNR 28.5 dB 评测输出 |
| 4.2 | VLA 语言指令操作 | [`vla_vlm_projects/01_smolvla_so101_engineering`](../vla_vlm_projects/01_smolvla_so101_engineering/) | 动作 chunk、标定流程、安全门控、dry-run | 1000+ 轨迹、92.5% 实机成功率、60 ms 端侧延迟 |
| 4.3 | VLM 工业 SOP 理解 | [`vla_vlm_projects/02_spatial_semantic_vla_engineering`](../vla_vlm_projects/02_spatial_semantic_vla_engineering/) · [SOP 公开分支](https://github.com/lemonbaby2/-123/tree/sop-public-cvat-roundtrip-20260825) | 语义—几何桥接、FSM 解耦设计、平台源码 | 98.2% 召回率与 3.5% 幻觉率的同口径复测 |
| 4.4 | ROS2 + 3DGS Lego 可视化 | [`projects/05_ros2_3dgs`](../projects/05_ros2_3dgs/) | PLY 解析、MarkerArray 转换、ROS2 包骨架 | 原 Lego 资产、12 秒录屏原件 |
| 4.6 | STM32-FreeRTOS BMS | [`projects/06_bms`](../projects/06_bms/) | Thevenin 模型、AEKF、均衡逻辑、调度预算 | 原 MCU 工程、HIL 测试报告 |
| 竞赛 | GaussPatrol 巡检 | [`projects/07_gausspatrol`](../projects/07_gausspatrol/) | 仿真代码、指标、13 项测试 | 实机性能 |
| — | 宁波螺钉装配 SOP / MES | [平台源码分支](https://github.com/lemonbaby2/-123/tree/sop-public-cvat-roundtrip-20260825) | 平台源码、部分验收文档 | 车间视频、生产凭据、数据库 |

### 口径说明

1. **本表不新增任何数字。** 简历里的每条指标都是历史报告值，仓库只负责标注"能不能复现"。
2. 标注为"未公开"的项目，是因为原始代码、数据或评测输出不在本仓库，**不是因为指标不成立**。
3. 逐条证据链见 [`docs/RESUME_EVIDENCE_MATRIX.md`](../docs/RESUME_EVIDENCE_MATRIX.md)，源码状态见 [`docs/RESUME_2026_PROJECT_INDEX.md`](../docs/RESUME_2026_PROJECT_INDEX.md)。

### 投递前需修正的原稿问题

| 位置 | 问题 | 建议 |
|---|---|---|
| 4.3 VLM 项目 | 时间写成 `2026.01 — 2025.03`，结束早于开始 | 核实后改为 `2025.03 — 2026.01` 或实际区间 |
| 教育背景 | `2020.09 — 2024.07` 与 `2025.08 — 至今` 并列，未说明是本科毕业后读硕 | 明确写"本科 / 硕士"分段 |
| 3.2 成果 1 与 3 | 同一条 48 ms 与 3.65× 重复表述两次 | 合并，避免评审认为凑字数 |
| 1.1 电话 / 邮箱 | 已在本文档打码，但 PDF 原件仍含完整联系方式 | PDF 用于投递，转录页用于公开展示；两者用途不同，不要互换 |
